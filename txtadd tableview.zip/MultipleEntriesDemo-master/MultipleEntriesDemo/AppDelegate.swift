//
//  AppDelegate.swift
//  Test
//
//  Created by Neil Hiddink on 8/19/18.
//  Copyright © 2018 Neil Hiddink. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        return true
    }

}

